package com.goddatax.tels;

import android.content.Intent;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;

public class GoddVpnService extends VpnService {
    private ParcelFileDescriptor vpnInterface;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            Builder builder = new Builder()
                    .setSession("GODDATAX TELS")
                    .setMtu(1500);

            // Intentionally no routes: this establishes an Android VPN
            // interface for the app's connection state without intercepting
            // or modifying Free Fire traffic.
            vpnInterface = builder.establish();
        } catch (Exception ignored) {}

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (vpnInterface != null) {
            try { vpnInterface.close(); } catch (Exception ignored) {}
            vpnInterface = null;
        }
        super.onDestroy();
    }
}
