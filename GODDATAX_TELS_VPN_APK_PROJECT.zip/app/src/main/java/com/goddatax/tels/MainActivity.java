package com.goddatax.tels;

import android.app.Activity;
import android.content.Intent;
import android.net.VpnService;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private static final int VPN_REQUEST = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WebView web = new WebView(this);
        web.setBackgroundColor(0xFF030509);
        web.setWebViewClient(new WebViewClient());

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);

        web.addJavascriptInterface(new Object() {
            @android.webkit.JavascriptInterface
            public void connectVpn() {
                Intent prep = VpnService.prepare(MainActivity.this);
                if (prep != null) {
                    startActivityForResult(prep, VPN_REQUEST);
                } else {
                    startVpn();
                }
            }

            @android.webkit.JavascriptInterface
            public void openFreeFire() {
                try {
                    Intent i = getPackageManager()
                            .getLaunchIntentForPackage("com.dts.freefireth");
                    if (i != null) startActivity(i);
                    else startActivity(new Intent(
                            Intent.ACTION_VIEW,
                            android.net.Uri.parse(
                            "https://play.google.com/store/apps/details?id=com.dts.freefireth")));
                } catch (Exception ignored) {}
            }
        }, "Android");

        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    private void startVpn() {
        startService(new Intent(this, GoddVpnService.class));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_REQUEST && resultCode == RESULT_OK) {
            startVpn();
        }
    }
}
